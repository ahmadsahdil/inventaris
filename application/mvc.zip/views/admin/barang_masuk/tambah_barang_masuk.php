<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#delete">
<i class="fa fa-cart-plus"></i>Tambah
</button>
<div class="modal modal-primary fade" id="delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Menambah data</h4>
      </div>
      <div class="modal-body">
        <p>Yakin ingin menambah data ini ?</p>
       
      
                    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
           <button type="button" class="btn btn-outline pull-right" data-dismiss="modal">Tidak, batalkan
           </button>
           <button type="submit" class="btn btn-outline pull-right">Ya, Tambah Data Ini</button>


      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->