<?php
// load data view do veriabel isi yang telah diset di controller
if ($isi) {
	$this->load->view($isi);
}
